
package com.mycompany.unicafe;

public class LyyraKortti {
 
    private double saldo;
 
    public LyyraKortti(double saldo) {
        this.saldo = saldo;
    }
 
    public double saldo() {
        return saldo;
    }
 
    public void lataaRahaa(double lisays) {
        this.saldo += lisays;
    }
 
    public boolean otaRahaa(double maara) {
        if (this.saldo < maara)
            return false;
 
        this.saldo = this.saldo - maara;
        return true;
    }
}
